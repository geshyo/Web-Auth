require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const connection = require("./db");
const userRoutes = require("./routes/users");
const authRoutes = require("./routes/auth");


// database connection
connection();

// middlewares
app.use(express.json());
app.use(cors());

// routes
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);
app.get("/", (req, res) => {
  return res.status(200).json({
    message:"server is running"
  });
});

const port = process.env.PORT || 8080;
const server = app.listen(port, (host = "127.0.0.1"));
console.log(`Listening on port http://localhost:${port}...`);
